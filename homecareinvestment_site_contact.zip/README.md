# Home Care Investment Website

This is a static website for **Home Care Investment - House Rentals**.

### Features
- About section
- Rentals section
- Contact section with phone call & WhatsApp chat button

### How to Deploy on GitHub Pages
1. Create a GitHub repository (e.g., `homecareinvestment`).
2. Upload all files from this ZIP to the repo.
3. In GitHub settings, enable **Pages** and set branch = `main`, folder = `/root`.
4. Your site will be live at `https://yourusername.github.io/homecareinvestment/`.
